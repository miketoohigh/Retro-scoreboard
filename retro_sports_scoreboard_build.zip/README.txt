RETRO SPORTS SCOREBOARD — FIRST BUILD

WHAT THIS IS
A single-file browser scoreboard for NBA, NFL, NHL and MLB. It uses ESPN's publicly accessible but undocumented scoreboard JSON endpoints. No API key is required. The feeds may change without notice, so this is a hobby project rather than a guaranteed commercial data service.

FILES
- index.html: the complete scoreboard app

RECOMMENDED LOW-COST HARDWARE
- 15.6-inch 1080p portable monitor with HDMI input and its own power supply.
- A browser-capable HDMI device. For a cheap first test, a Fire TV Stick with Silk can open the hosted page, but Silk is not a guaranteed kiosk/auto-start solution. After a power interruption, you may need to reopen Silk and the saved page.
- A small wall shelf or VESA mount if the monitor supports it.

IMPORTANT BUDGET NOTE
A monitor alone may consume $40–70 of the $100 budget. The compute device, mount and cables can push the complete build over $100. The cheapest reliable approach is to reuse a browser-capable device if available, or buy a used mini PC / Android device later. Do not buy the monitor until you confirm the HDMI input and power arrangement.

HOSTING THE PAGE
1. On a computer or phone browser, create a free GitHub account if needed.
2. Create a new public repository named retro-scoreboard.
3. Upload this file and name it index.html.
4. In the repository, open Settings > Pages.
5. Under Build and deployment, choose Deploy from a branch, select main and /(root), then Save.
6. Wait for GitHub Pages to publish. The page URL will look like:
   https://YOUR-USERNAME.github.io/retro-scoreboard/
7. Open that URL on a browser-capable HDMI device. Use full-screen mode if available.

TEST BEFORE MOUNTING
1. Open index.html from the published GitHub Pages URL.
2. Confirm all four leagues load. On days with no games for a league, that league simply won't appear in the ticker.
3. Leave it running for at least 30 minutes and confirm refreshes.
4. Test a restart/power interruption before wall mounting.

CONTROLS
- BATHROOM MODE button: switches to green lettering and rotating restroom messages.
- REFRESH button: immediately reloads the sports feeds.
- Keyboard B: toggle bathroom mode.
- Keyboard R: refresh feeds.

DATA / RELIABILITY
- ESPN scoreboard endpoints are undocumented and may change or rate-limit requests. The app refreshes every 30 seconds and displays a fallback if feeds fail.
- Scores/status are near-live, not guaranteed frame-by-frame. Game clock detail is whatever ESPN supplies.
- No API key or login is embedded in the page.
- The score feed is not affiliated with ESPN.
